import RoundCountdown from '../components/trading/RoundCountdown';
import OrderForm from '../components/trading/OrderForm';
import EncryptedOrderCard from '../components/trading/EncryptedOrderCard';
import UserStatsCard from '../components/results/UserStatsCard';

function TradingPage() {
  return (
    <div className="container mx-auto p-4 lg:p-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Order Form */}
        <div className="lg:col-span-1 space-y-8">
          <OrderForm />
          <UserStatsCard />
        </div>

        {/* Middle Column: Countdown */}
        <div className="lg:col-span-1 flex items-center justify-center">
          <RoundCountdown />
        </div>

        {/* Right Column: Order Book */}
        <div className="lg:col-span-1 space-y-4">
          <h2 className="text-2xl font-heading font-bold text-center">Order Book</h2>
          <div className="glass rounded-2xl p-4 space-y-4 max-h-[60vh] overflow-y-auto scrollbar-hide">
            <EncryptedOrderCard />
            <EncryptedOrderCard />
            <EncryptedOrderCard />
            <EncryptedOrderCard />
          </div>
        </div>
      </div>
    </div>
  );
}

export default TradingPage;
