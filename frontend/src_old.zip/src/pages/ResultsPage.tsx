function ResultsPage() {
  return (
    <div className="text-white">
      <h1 className="text-3xl font-bold">Results Page</h1>
      <p>This is where the results will be displayed.</p>
    </div>
  );
}

export default ResultsPage;