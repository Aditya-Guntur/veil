import { useState } from 'react'
import { motion } from 'framer-motion'
import { Lock, Zap, Network, ArrowRight, Clock, TrendingUp } from 'lucide-react'
import { AnimatedBackground } from './components/AnimatedBackground'
import './index.css'

function App() {
  const [connected, setConnected] = useState(false)

  return (
    <>
      <AnimatedBackground />
      
      <div className="min-h-screen relative">
        {/* Noise Texture Overlay */}
        <div className="fixed inset-0 opacity-[0.015] pointer-events-none"
             style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 400 400\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.9\' numOctaves=\'4\' /%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\' /%3E%3C/svg%3E")' }} />

        {/* Header */}
        <header className="relative z-10 border-b border-white/5 backdrop-blur-xl">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center py-6">
              {/* Logo */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center space-x-3"
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-veil-accent blur-xl opacity-50 animate-pulse-slow" />
                  <div className="relative text-4xl">⛓️</div>
                </div>
                <h1 className="text-3xl font-bold gradient-text">VEIL</h1>
              </motion.div>

              {/* Connect Button */}
              <motion.button
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                onClick={() => setConnected(!connected)}
                className="btn-glow px-6 py-3 bg-white text-black rounded-xl font-semibold hover:bg-gray-200"
              >
                {connected ? (
                  <span className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-veil-accent rounded-full animate-pulse" />
                    0x1a2b...3c4d
                  </span>
                ) : (
                  'Connect Wallet'
                )}
              </motion.button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="relative z-10">
          {!connected ? (
            // Landing Page
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
              {/* Hero */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="text-center space-y-8 mb-20"
              >
                <motion.div
                  initial={{ scale: 0.9 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 1, ease: "easeOut" }}
                >
                  <h2 className="text-7xl md:text-8xl lg:text-9xl font-bold text-white mb-6">
                    Trade in the
                  </h2>
                  <h2 className="text-7xl md:text-8xl lg:text-9xl font-bold gradient-text-purple mb-6">
                    Shadows
                  </h2>
                </motion.div>
                
                <motion.p 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                  className="text-xl md:text-2xl text-gray-400 max-w-3xl mx-auto leading-relaxed"
                >
                  The first <span className="text-white font-bold border-b-2 border-white">encrypted cross-chain DEX</span> where
                  front-running is <span className="text-veil-cyan font-semibold">cryptographically impossible</span>
                </motion.p>

                {/* CTA Buttons */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-12"
                >
                  <button
                    onClick={() => setConnected(true)}
                    className="group btn-glow px-10 py-5 bg-gradient-to-r from-veil-accent via-veil-cyan to-veil-light text-black rounded-2xl font-bold text-lg flex items-center gap-3"
                  >
                    Enter the Veil
                    <ArrowRight className="group-hover:translate-x-1 transition-transform" size={20} />
                  </button>
                  
                  <button className="px-10 py-5 glass rounded-2xl font-semibold text-lg hover:bg-white/10 transition-all">
                    Learn More
                  </button>
                </motion.div>
              </motion.div>

              {/* Stats Bar */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
                className="glass-strong rounded-3xl p-8 mb-20 max-w-4xl mx-auto"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                  <div className="space-y-2">
                    <div className="text-5xl font-bold text-white">$0</div>
                    <div className="text-sm text-gray-400 uppercase tracking-wider">MEV Extracted</div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-5xl font-bold gradient-text">100%</div>
                    <div className="text-sm text-gray-400 uppercase tracking-wider">Fair Pricing</div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-5xl font-bold gradient-text">0ms</div>
                    <div className="text-sm text-gray-400 uppercase tracking-wider">Front-Run Time</div>
                  </div>
                </div>
              </motion.div>

              {/* Features Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-20">
                {[ 
                  {
                    icon: <Lock size={40} />,
                    title: 'Encrypted Orders',
                    description: 'Orders stay hidden using ICP\'s vetKeys until simultaneous reveal',
                    delay: 0.8
                  },
                  {
                    icon: <Zap size={40} />,
                    title: 'Fair Clearing Price',
                    description: 'Everyone trades at the same uniform price. No MEV possible',
                    delay: 0.9
                  },
                  {
                    icon: <Network size={40} />,
                    title: 'Native Cross-Chain',
                    description: 'Execute on Bitcoin & Ethereum with threshold signatures',
                    delay: 1.0
                  },
                ].map((feature, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: feature.delay }}
                    className="glass glow-box rounded-3xl p-8 card-hover group"
                  >
                    <div className="text-veil-accent mb-6 group-hover:scale-110 transition-transform duration-300">
                      {feature.icon}
                    </div>
                    <h3 className="text-2xl font-bold mb-4 text-white">
                      {feature.title}
                    </h3>
                    <p className="text-gray-400 leading-relaxed">
                      {feature.description}
                    </p>
                  </motion.div>
                ))}
              </div>

              {/* Bottom Glow Line */}
              <div className="neon-line w-full max-w-4xl mx-auto" />
            </div>
          ) : (
            // Trading Interface
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
              {/* Countdown Timer */}
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="glass-strong rounded-3xl p-12 text-center glow-box"
              >
                <div className="text-sm text-gray-400 uppercase tracking-wider mb-4">Round #42</div>
                <div className="flex items-center justify-center gap-4 mb-6">
                  <Clock className="text-veil-accent" size={40} />
                  <div className="text-8xl font-bold font-mono gradient-text">
                    00:42
                  </div>
                </div>
                <div className="relative w-full h-4 bg-black/50 rounded-full overflow-hidden mb-4">
                  <motion.div
                    className="absolute inset-y-0 left-0 bg-gradient-to-r from-veil-accent via-veil-cyan to-veil-light rounded-full"
                    initial={{ width: '0%' }}
                    animate={{ width: '70%' }}
                    transition={{ duration: 1 }}
                  />
                </div>
                <div className="flex items-center justify-center gap-6 text-sm text-gray-400">
                  <span className="flex items-center gap-2">
                    <Lock size={16} />
                    4 orders encrypted
                  </span>
                  <span className="flex items-center gap-2">
                    <TrendingUp size={16} />
                    Revealing soon...
                  </span>
                </div>
              </motion.div>

              {/* Trading Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Order Form */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="glass rounded-3xl p-8"
                >
                  <h3 className="text-3xl font-bold mb-8 gradient-text">Submit Order</h3>
                  
                  {/* Buy/Sell Toggle */}
                  <div className="flex gap-3 mb-8">
                    <button className="flex-1 py-4 bg-white text-black rounded-xl font-bold text-lg hover:bg-gray-200 transition-colors">
                      Buy
                    </button>
                    <button className="flex-1 py-4 bg-bg-card text-gray-400 rounded-xl font-bold text-lg hover:bg-bg-card/80 transition-all">
                      Sell
                    </button>
                  </div>

                  {/* Inputs */}
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm text-gray-400 mb-3 uppercase tracking-wider">Amount</label>
                      <div className="relative">
                        <input
                          type="number"
                          placeholder="0.00"
                          className="w-full px-6 py-4 bg-black/50 border border-white/10 rounded-xl text-white text-2xl font-mono focus:outline-none focus:border-veil-accent focus:ring-2 focus:ring-veil-accent/20 transition-all"
                        />
                        <span className="absolute right-6 top-1/2 -translate-y-1/2 text-gray-500 font-semibold">ETH</span>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm text-gray-400 mb-3 uppercase tracking-wider">Max Price</label>
                      <div className="relative">
                        <input
                          type="number"
                          placeholder="0.00"
                          className="w-full px-6 py-4 bg-black/50 border border-white/10 rounded-xl text-white text-2xl font-mono focus:outline-none focus:border-veil-accent focus:ring-2 focus:ring-veil-accent/20 transition-all"
                        />
                        <span className="absolute right-6 top-1/2 -translate-y-1/2 text-gray-500 font-semibold">USD</span>
                      </div>
                    </div>
                  </div>

                  {/* Info Box */}
                  <div className="mt-8 p-6 bg-gray-900 border border-gray-700 rounded-xl">
                    <p className="text-sm text-gray-300 leading-relaxed">
                      💡 Your order will be <span className="text-white font-bold border-b-2 border-white">encrypted</span> and revealed at 00:00 with all others
                    </p>
                  </div>

                  {/* Submit */}
                  <button className="w-full mt-8 py-5 bg-white text-black rounded-xl font-bold text-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-3">
                    <Lock size={20} />
                    Encrypt & Submit Order
                  </button>
                </motion.div>

                {/* Order Book */}
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="glass rounded-3xl p-8"
                >
                  <h3 className="text-3xl font-bold mb-8 gradient-text">Order Book</h3>
                  
                  <div className="space-y-4">
                    {[1, 2, 3, 4].map((i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="shimmer bg-bg-card border border-white/10 rounded-xl p-6 hover:border-veil-accent/50transition-all"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="p-3 bg-veil-dark rounded-lg">
                              <Lock className="text-veil-accent" size={24} />
                            </div>
                            <div>
                              <div className="font-bold text-lg">Order #{i}</div>
                              <div className="text-sm text-gray-400">Encrypted • Revealing at 00:00</div>
                            </div>
                          </div>
                          {i === 1 && (
                            <span className="px-3 py-1 bg-veil-accent/20 text-veil-accent rounded-lg text-sm font-semibold">
                              Yours
                            </span>
                          )}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                  <div className="mt-8 text-center">
                    <div className="inline-flex items-center gap-2 text-gray-400">
                      <div className="w-2 h-2 bg-veil-accent rounded-full animate-pulse" />
                      <span className="text-sm">Waiting for round to complete...</span>
                    </div>
                  </div>
                </motion.div>
              </div>

              {/* Your Stats */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="glass-strong rounded-3xl p-8"
              >
                <h3 className="text-2xl font-bold mb-6 gradient-text">Your Stats This Round</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-6 bg-black/30 rounded-xl">
                    <div className="text-4xl font-bold gradient-text mb-2">2</div>
                    <div className="text-sm text-gray-400 uppercase tracking-wider">Orders Submitted</div>
                  </div>
                  <div className="text-center p-6 bg-black/30 rounded-xl">
                    <div className="text-4xl font-bold gradient-text mb-2">15 ETH</div>
                    <div className="text-sm text-gray-400 uppercase tracking-wider">Total Volume</div>
                  </div>
                  <div className="text-center p-6 bg-black/30 rounded-xl">
                    <div className="text-4xl font-bold gradient-text mb-2">$3,050</div>
                    <div className="text-sm text-gray-400 uppercase tracking-wider">Avg Price Target</div>
                  </div>
                </div>
              </motion.div>
            </div>
          )}
        </main>

        {/* Footer */}
        <footer className="relative z-10 border-t border-white/5 mt-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center space-y-4">
              <div className="flex items-center justify-center gap-8 text-sm text-gray-500">
                <span className="flex items-center gap-2">
                  <div />
                  <span>•</span>
                  Built on Internet Computer
                </span>
                <span>•</span>
                <span>Powered by vetKeys</span>
                <span>•</span>
                <span>Threshold Signatures</span>
              </div>
              <div className="text-xl font-semibold gradient-text">
                © 2025 Veil. All rights reserved.
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  )
}
export default App
