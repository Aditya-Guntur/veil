import React from 'react';
import { motion } from 'framer-motion';
import { Card } from '../ui/Card';
import { TrendingUp, CheckCircle, DollarSign } from 'lucide-react';

interface UserStatsCardProps {
  ordersFilled: number;
  ordersSubmitted: number;
  surplusEarned: number;
  rank: number;
  totalPlayers: number;
}

export const UserStatsCard: React.FC<UserStatsCardProps> = ({
  ordersFilled,
  ordersSubmitted,
  surplusEarned,
  rank,
  totalPlayers,
}) => {
  const fillRate = (ordersFilled / ordersSubmitted) * 100;
  const isWinner = surplusEarned > 0;

  return (
    <Card glow={isWinner}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h3 className="text-2xl font-bold">Your Performance</h3>
          {isWinner && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', delay: 0.2 }}
            >
              <span className="text-3xl">🏆</span>
            </motion.div>
          )}
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-4">
          {/* Orders Filled */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-center"
          >
            <CheckCircle className="mx-auto mb-2 text-green-400" size={32} />
            <div className="text-3xl font-bold">
              {ordersFilled}/{ordersSubmitted}
            </div>
            <div className="text-xs text-gray-400 mt-1">Orders Filled</div>
            <div className={`text-sm font-semibold mt-1 ${
              fillRate === 100 ? 'text-green-400' : 'text-yellow-400'
            }`}>
              {fillRate.toFixed(0)}%
            </div>
          </motion.div>

          {/* Surplus Earned */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-center"
          >
            <DollarSign className={`mx-auto mb-2 ${
              surplusEarned > 0 ? 'text-green-400' : 'text-gray-400'
            }`} size={32} />
            <div className={`text-3xl font-bold ${
              surplusEarned > 0 ? 'text-green-400' : 'text-gray-400'
            }`}>
              ${Math.abs(surplusEarned).toFixed(2)}
            </div>
            <div className="text-xs text-gray-400 mt-1">Surplus Earned</div>
            {surplusEarned > 0 && (
              <div className="text-sm text-green-400 font-semibold mt-1">
                You saved money! 💚
              </div>
            )}
          </motion.div>

          {/* Rank */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-center"
          >
            <TrendingUp className="mx-auto mb-2 text-veil-cyan" size={32} />
            <div className="text-3xl font-bold">
              #{rank}
            </div>
            <div className="text-xs text-gray-400 mt-1">Rank</div>
            <div className="text-sm text-gray-300 mt-1">
              of {totalPlayers} players
            </div>
          </motion.div>
        </div>

        {/* Strategy Feedback */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className={`p-4 rounded-lg ${
            isWinner 
              ? 'bg-green-500/10 border border-green-500/30' 
              : 'bg-gray-800/50 border border-gray-700'
          }`}
        >
          <div className="text-sm">
            {isWinner ? (
              <>
                <span className="font-semibold text-green-400">✅ Great Strategy!</span>
                <p className="text-gray-300 mt-1">
                  You predicted the market correctly and earned surplus by {fillRate === 100 ? 'positioning all your orders perfectly' : 'strategically pricing your orders'}.
                </p>
              </>
            ) : (
              <>
                <span className="font-semibold text-gray-400">💡 Strategy Tip</span>
                <p className="text-gray-300 mt-1">
                  {fillRate === 0 
                    ? 'Your orders didn\'t fill. Try pricing closer to recent clearing prices.'
                    : 'Some orders didn\'t fill. Study historical data to improve predictions.'
                  }
                </p>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </Card>
  );
};