// src/components/trading/RoundCountdown.tsx
import React from 'react';
import { motion } from 'framer-motion';
import { Clock } from 'lucide-react';
import { useCountdown } from '../../hooks/useCountdown';

interface RoundCountdownProps {
  endTime: number; // Unix timestamp
  roundId: number;
}

export const RoundCountdown: React.FC<RoundCountdownProps> = ({
  endTime,
  roundId,
}) => {
  const { minutes, seconds, progress, isUrgent } = useCountdown(endTime);

  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="relative"
    >
      {/* Main Card */}
      <div className={`
        glass rounded-3xl p-8 text-center
        ${isUrgent ? 'ring-4 ring-red-500 animate-pulse' : 'ring-2 ring-veil-accent/30'}
      `}>
        {/* Round Number */}
        <div className="text-sm text-gray-400 mb-2">
          Round #{roundId}
        </div>

        {/* Timer */}
        <div className="flex items-center justify-center gap-4 mb-4">
          <div className="relative">
            <div className="text-7xl font-bold font-mono tabular-nums">
              {minutes.toString().padStart(2, '0')}
            </div>
            <div className="text-xs text-gray-400 mt-1">MINUTES</div>
          </div>
          
          <div className="text-7xl font-bold text-veil-accent animate-pulse">
            :
          </div>
          
          <div className="relative">
            <div className="text-7xl font-bold font-mono tabular-nums">
              {seconds.toString().padStart(2, '0')}
            </div>
            <div className="text-xs text-gray-400 mt-1">SECONDS</div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-gray-800 rounded-full h-3 overflow-hidden">
          <motion.div
            className={`h-full rounded-full ${
              isUrgent 
                ? 'bg-gradient-to-r from-red-500 to-orange-500' 
                : 'bg-gradient-to-r from-veil-light to-veil-cyan'
            }`}
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>

        {/* Status Text */}
        <div className="mt-4 text-sm text-gray-300">
          {isUrgent ? (
            <span className="text-red-400 font-semibold animate-pulse">
              ⚠️ LAST 10 SECONDS!
            </span>
          ) : (
            <span>
              <Clock className="inline mr-1" size={14} />
              Orders revealing soon...
            </span>
          )}
        </div>
      </div>

      {/* Glow Ring (pulsing) */}
      {!isUrgent && (
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 rounded-3xl bg-veil-accent/20 blur-2xl pulse-ring" />
        </div>
      )}
    </motion.div>
  );
};

export default RoundCountdown; 